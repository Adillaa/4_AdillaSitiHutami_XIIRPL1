<?php
session_start();
include "../config/koneksi.php";
$id_user = $_SESSION['id'];

$buku = mysqli_query($koneksi, "SELECT * FROM buku WHERE stok > 0");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Peminjaman Buku</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<div class="container mt-4">

    <!-- HEADER -->
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h4 class="fw-bold">📖 Peminjaman Buku</h4>
        <a href="dashboard.php" class="btn btn-secondary btn-sm">
            ⬅ Kembali ke Dashboard
        </a>
    </div>

    <!-- CARD -->
    <div class="card shadow-sm">
        <div class="card-body">

            <?php if (mysqli_num_rows($buku) == 0) { ?>
                <div class="alert alert-info text-center">
                    Tidak ada buku yang tersedia untuk dipinjam.
                </div>
            <?php } else { ?>

            <table class="table table-bordered table-hover align-middle">
                <thead class="table-dark text-center">
                    <tr>
                        <th width="50">No</th>
                        <th>Judul Buku</th>
                        <th>Penulis</th>
                        <th width="80">Stok</th>
                        <th width="120">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                <?php $no=1; while($b=mysqli_fetch_assoc($buku)) { ?>
                    <tr>
                        <td class="text-center"><?= $no++ ?></td>
                        <td><?= $b['judul'] ?></td>
                        <td><?= $b['penulis'] ?></td>
                        <td class="text-center">
                            <span class="badge bg-success">
                                <?= $b['stok'] ?>
                            </span>
                        </td>
                        <td class="text-center">
                            <a href="proses_pinjam.php?id=<?= $b['id'] ?>" 
                               class="btn btn-success btn-sm"
                               onclick="return confirm('Yakin ingin meminjam buku ini?')">
                               📥 Pinjam
                            </a>
                        </td>
                    </tr>
                <?php } ?>
                </tbody>
            </table>

            <?php } ?>

        </div>
    </div>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
