<?php
include "../config/koneksi.php";

$id = $_GET['id'];
$id_buku = $_GET['buku'];
$tgl = date('Y-m-d');

mysqli_query($koneksi, "UPDATE transaksi SET 
    status='dikembalikan',
    tanggal_kembali='$tgl'
    WHERE id='$id'
");

mysqli_query($koneksi, "UPDATE buku SET stok = stok + 1 WHERE id='$id_buku'");

header("Location: dashboard.php");
