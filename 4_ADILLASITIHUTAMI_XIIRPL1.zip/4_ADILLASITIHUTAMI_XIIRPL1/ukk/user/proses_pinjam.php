<?php
session_start();
include "../config/koneksi.php";

$id_user = $_SESSION['id'];
$id_buku = $_GET['id'];
$tgl = date('Y-m-d');

mysqli_query($koneksi, "INSERT INTO transaksi VALUES (
    NULL,
    '$id_user',
    '$id_buku',
    '$tgl',
    NULL,
    'dipinjam'
)");

mysqli_query($koneksi, "UPDATE buku SET stok = stok - 1 WHERE id='$id_buku'");

header("Location: dashboard.php");
