<?php
session_start();
include "../config/koneksi.php";

/* VALIDASI LOGIN */
if (!isset($_SESSION['login']) || $_SESSION['role'] != 'user' || !isset($_SESSION['id'])) {
    header("Location: ../auth/login.php");
    exit;
}

$id_user = $_SESSION['id'];

/* BUKU YANG MASIH DIPINJAM */
$dipinjam = mysqli_query($koneksi, "
    SELECT transaksi.*, buku.judul
    FROM transaksi
    JOIN buku ON transaksi.id_buku = buku.id
    WHERE transaksi.id_user='$id_user'
    AND transaksi.status='dipinjam'
    ORDER BY transaksi.id DESC
");

/* RIWAYAT PEMINJAMAN (SELESAI) */
$riwayat = mysqli_query($koneksi, "
    SELECT transaksi.*, buku.judul
    FROM transaksi
    JOIN buku ON transaksi.id_buku = buku.id
    WHERE transaksi.id_user='$id_user'
    AND transaksi.status='dikembalikan'
    ORDER BY transaksi.id DESC
");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Dashboard User</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background: #f4f6f9; }
        .menu-card {
            border-radius: 16px;
            box-shadow: 0 10px 25px rgba(0,0,0,.08);
            transition: 0.3s;
        }
        .menu-card:hover { transform: translateY(-5px); }
        .menu-icon { font-size: 40px; }
        .badge { padding: 6px 12px; font-size: .85rem; }
    </style>
</head>
<body>

<div class="container mt-5">

    <!-- HEADER -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h4 class="fw-bold">👋 Selamat Datang Dashboard <?= $_SESSION['nama']; ?></h4>
        <a href="../auth/logout.php" class="btn btn-danger btn-sm">Logout</a>
    </div>

    <!-- MENU -->
    <div class="row mb-4">
        <div class="col-md-6 mb-3">
            <div class="card menu-card text-center p-4">
                <div class="menu-icon mb-2">📥</div>
                <h5 class="fw-bold">Pinjam Buku</h5>
                <p class="text-muted">Lakukan peminjaman buku</p>
                <a href="pinjam.php" class="btn btn-success">Pinjam Buku</a>
            </div>
        </div>

        <div class="col-md-6 mb-3">
            <div class="card menu-card text-center p-4">
                <div class="menu-icon mb-2">📜</div>
                <h5 class="fw-bold">Riwayat</h5>
                <p class="text-muted">Lihat buku yang sudah dikembalikan</p>
                <a href="#riwayat" class="btn btn-primary">Lihat Riwayat</a>
            </div>
        </div>
    </div>

    <!-- BUKU SEDANG DIPINJAM -->
    <div class="card shadow-sm mb-4">
        <div class="card-header bg-warning fw-bold">
            📌 Buku yang Sedang Dipinjam
        </div>
        <div class="card-body">

        <?php if (mysqli_num_rows($dipinjam) == 0) { ?>
            <div class="alert alert-info text-center">
                Tidak ada buku yang sedang dipinjam.
            </div>
        <?php } else { ?>

        <table class="table table-bordered align-middle">
            <tr class="table-dark text-center">
                <th>Buku</th>
                <th>Tgl Pinjam</th>
                <th>Aksi</th>
            </tr>

            <?php while($d = mysqli_fetch_assoc($dipinjam)) { ?>
            <tr>
                <td><?= $d['judul'] ?></td>
                <td class="text-center"><?= $d['tanggal_pinjam'] ?></td>
                <td class="text-center">
                    <a href="kembali.php?id=<?= $d['id'] ?>&buku=<?= $d['id_buku'] ?>"
                       class="btn btn-warning btn-sm"
                       onclick="return confirm('Kembalikan buku ini?')">
                        Kembalikan
                    </a>
                </td>
            </tr>
            <?php } ?>
        </table>

        <?php } ?>
        </div>
    </div>

    <!-- RIWAYAT -->
    <div class="card shadow-sm" id="riwayat">
        <div class="card-header bg-primary text-white fw-bold">
            📚 Riwayat Peminjaman
        </div>
        <div class="card-body">

        <?php if (mysqli_num_rows($riwayat) == 0) { ?>
            <div class="alert alert-info text-center">
                Belum ada riwayat peminjaman.
            </div>
        <?php } else { ?>

        <table class="table table-bordered align-middle">
            <tr class="table-dark text-center">
                <th>Buku</th>
                <th>Tgl Pinjam</th>
                <th>Tgl Kembali</th>
                <th>Status</th>
            </tr>

            <?php while($r = mysqli_fetch_assoc($riwayat)) { ?>
            <tr>
                <td><?= $r['judul'] ?></td>
                <td class="text-center"><?= $r['tanggal_pinjam'] ?></td>
                <td class="text-center"><?= $r['tanggal_kembali'] ?></td>
                <td class="text-center">
                    <span class="badge bg-success">Dikembalikan</span>
                </td>
            </tr>
            <?php } ?>
        </table>

        <?php } ?>
        </div>
    </div>

</div>

</body>
</html>
