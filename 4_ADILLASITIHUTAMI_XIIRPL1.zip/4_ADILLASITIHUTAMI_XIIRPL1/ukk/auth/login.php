<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Login | Sistem Perpustakaan</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        body {
            min-height: 100vh;
            background: linear-gradient(135deg, #808000);
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .login-card {
            border-radius: 16px;
            box-shadow: 0 15px 40px rgba(0,0,0,.25);
            overflow: hidden;
        }
        .login-header {
            background: #0f6fff;
        }
        .login-icon {
            font-size: 48px;
        }
        .form-control {
            border-radius: 10px;
        }
        .btn {
            border-radius: 10px;
        }
    </style>
</head>
<body>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-4 col-sm-8">

            <div class="card login-card">
                <!-- HEADER -->
                <div class="card-header login-header text-white text-center py-4">
                    <div class="login-icon mb-2">📚</div>
                    <h4 class="mb-0 fw-bold">Sistem Perpustakaan</h4>
                    <small>SMKN 1 Karawang</small>
                </div>

                <!-- BODY -->
                <div class="card-body p-4">
                    <form action="proses_login.php" method="POST">
                        <div class="mb-3">
                            <label class="form-label fw-semibold">Username</label>
                            <input type="text" name="username"
                                   class="form-control"
                                   placeholder="Masukkan username"
                                   required>
                        </div>

                        <div class="mb-4">
                            <label class="form-label fw-semibold">Password</label>
                            <input type="password" name="password"
                                   class="form-control"
                                   placeholder="Masukkan password"
                                   required>
                        </div>

                        <button class="btn btn-danger w-100 fw-semibold">
                            🔐 Login
                        </button>
                    </form>
                </div>

                <!-- FOOTER -->
                <div class="card-footer text-center text-muted small">
                    © <?= date('Y') ?> Sistem Perpustakaan
                </div>
            </div>

        </div>
    </div>
</div>

</body>
</html>
