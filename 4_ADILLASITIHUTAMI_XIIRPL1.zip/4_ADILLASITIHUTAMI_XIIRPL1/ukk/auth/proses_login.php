<?php
session_start();
include "../config/koneksi.php";

$username = $_POST['username'];
$password = $_POST['password'];

$query = mysqli_query($koneksi, "SELECT * FROM users WHERE username='$username'");
$data = mysqli_fetch_assoc($query);

if ($data && password_verify($password, $data['password'])) {

    $_SESSION['login'] = true;
    $_SESSION['id']    = $data['id']; 
    $_SESSION['role']  = $data['role'];
    $_SESSION['nama']  = $data['nama'];

    if ($data['role'] == 'admin') {
        header("Location: ../admin/dashboard.php");
        exit;
    } else {
        header("Location: ../user/dashboard.php");
        exit;
    }

} else {
    echo "<script>
        alert('Username atau Password salah!');
        location='login.php';
    </script>";
}
?>
