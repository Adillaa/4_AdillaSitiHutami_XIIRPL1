<?php
session_start();
include "../config/koneksi.php";

if (!isset($_SESSION['login']) || $_SESSION['role'] != 'admin') {
    header("Location: ../auth/login.php");
    exit;
}

$cari = isset($_GET['cari']) ? $_GET['cari'] : '';

$data = mysqli_query($koneksi, 
    "SELECT * FROM users 
     WHERE role='user'
     AND nama LIKE '%$cari%'
     ORDER BY id DESC"
);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Data Anggota</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<div class="container mt-4">

    <!-- HEADER -->
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h4 class="fw-bold">👥 Manajemen Data Anggota</h4>
        <a href="dashboard.php" class="btn btn-secondary btn-sm">
            ⬅ Kembali ke Dashboard
        </a>
    </div>

    <!-- SEARCH -->
    <form method="GET" class="mb-3 d-flex">
        <input type="text" name="cari" class="form-control me-2"
               placeholder="Cari nama anggota..."
               value="<?= $cari ?>">
        <button class="btn btn-primary">Cari</button>
    </form>

    <!-- TAMBAH -->
    <button class="btn btn-success mb-3" data-bs-toggle="modal" data-bs-target="#tambah">
        ➕ Tambah Anggota
    </button>

    <!-- TABLE -->
    <div class="card shadow-sm">
        <div class="card-body">
            <table class="table table-bordered align-middle">
                <tr class="table-dark text-center">
                    <th width="50">No</th>
                    <th>Nama</th>
                    <th>Username</th>
                    <th width="160">Aksi</th>
                </tr>

                <?php $no=1; while($a=mysqli_fetch_assoc($data)) { ?>
                <tr>
                    <td class="text-center"><?= $no++ ?></td>
                    <td><?= $a['nama'] ?></td>
                    <td><?= $a['username'] ?></td>
                    <td class="text-center">
                        <button class="btn btn-warning btn-sm"
                                data-bs-toggle="modal"
                                data-bs-target="#edit<?= $a['id'] ?>">
                            ✏ Edit
                        </button>

                        <a href="hapus_anggota.php?id=<?= $a['id'] ?>"
                           onclick="return confirm('Hapus anggota ini?')"
                           class="btn btn-danger btn-sm">
                            🗑 Hapus
                        </a>
                    </td>
                </tr>

                <!-- MODAL EDIT -->
                <div class="modal fade" id="edit<?= $a['id'] ?>">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <form method="POST" action="edit_anggota.php">
                                <div class="modal-header">
                                    <h5 class="modal-title">Edit Anggota</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                </div>
                                <div class="modal-body">
                                    <input type="hidden" name="id" value="<?= $a['id'] ?>">

                                    <label>Nama</label>
                                    <input type="text" name="nama" class="form-control mb-2"
                                           value="<?= $a['nama'] ?>" required>

                                    <label>Username</label>
                                    <input type="text" name="username" class="form-control mb-2"
                                           value="<?= $a['username'] ?>" required>

                                    <label>Password (opsional)</label>
                                    <input type="password" name="password" class="form-control"
                                           placeholder="Kosongkan jika tidak diubah">
                                </div>
                                <div class="modal-footer">
                                    <button class="btn btn-warning">Update</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>

                <?php } ?>
            </table>
        </div>
    </div>
</div>

<!-- MODAL TAMBAH -->
<div class="modal fade" id="tambah">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="POST" action="tambah_anggota.php">
                <div class="modal-header">
                    <h5 class="modal-title">Tambah Anggota</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <label>Nama</label>
                    <input type="text" name="nama" class="form-control mb-2" required>

                    <label>Username</label>
                    <input type="text" name="username" class="form-control mb-2" required>

                    <label>Password</label>
                    <input type="password" name="password" class="form-control" required>
                </div>
                <div class="modal-footer">
                    <button class="btn btn-success">Simpan</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
