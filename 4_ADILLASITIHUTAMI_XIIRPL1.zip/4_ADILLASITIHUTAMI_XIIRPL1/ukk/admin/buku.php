<?php
session_start();
include "../config/koneksi.php";

if (!isset($_SESSION['login']) || $_SESSION['role'] != 'admin') {
    header("Location: ../auth/login.php");
    exit;
}

$keyword = isset($_GET['cari']) ? $_GET['cari'] : '';
$query = mysqli_query($koneksi, 
    "SELECT * FROM buku 
     WHERE judul LIKE '%$keyword%' 
     OR penulis LIKE '%$keyword%'
     ORDER BY id DESC"
);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Data Buku</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<div class="container mt-4">

    <!-- HEADER -->
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h4 class="fw-bold">📚 Manajemen Data Buku</h4>
        <a href="dashboard.php" class="btn btn-secondary btn-sm">
            ⬅ Kembali ke Dashboard
        </a>
    </div>

    <!-- SEARCH -->
    <form method="GET" class="mb-3 d-flex">
        <input type="text" name="cari" class="form-control me-2"
               placeholder="Cari judul atau penulis..."
               value="<?= $keyword ?>">
        <button class="btn btn-primary">Cari</button>
    </form>

    <!-- TAMBAH -->
    <button class="btn btn-success mb-3" data-bs-toggle="modal" data-bs-target="#tambah">
        ➕ Tambah Buku
    </button>

    <!-- TABLE -->
    <div class="card shadow-sm">
        <div class="card-body">
            <table class="table table-bordered align-middle">
                <tr class="table-dark text-center">
                    <th width="50">No</th>
                    <th>Judul</th>
                    <th>Penulis</th>
                    <th width="80">Stok</th>
                    <th width="160">Aksi</th>
                </tr>

                <?php $no=1; while($b = mysqli_fetch_assoc($query)) { ?>
                <tr>
                    <td class="text-center"><?= $no++ ?></td>
                    <td><?= $b['judul'] ?></td>
                    <td><?= $b['penulis'] ?></td>
                    <td class="text-center"><?= $b['stok'] ?></td>
                    <td class="text-center">
                        <button class="btn btn-warning btn-sm"
                                data-bs-toggle="modal"
                                data-bs-target="#edit<?= $b['id'] ?>">
                            ✏ Edit
                        </button>

                        <a href="hapus_buku.php?id=<?= $b['id'] ?>"
                           onclick="return confirm('Hapus data buku?')"
                           class="btn btn-danger btn-sm">
                            🗑 Hapus
                        </a>
                    </td>
                </tr>

                <!-- MODAL EDIT -->
                <div class="modal fade" id="edit<?= $b['id'] ?>">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <form method="POST" action="edit_buku.php">
                                <div class="modal-header">
                                    <h5 class="modal-title">Edit Buku</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                </div>
                                <div class="modal-body">
                                    <input type="hidden" name="id" value="<?= $b['id'] ?>">
                                    <label>Judul</label>
                                    <input type="text" name="judul" class="form-control mb-2"
                                           value="<?= $b['judul'] ?>" required>

                                    <label>Penulis</label>
                                    <input type="text" name="penulis" class="form-control mb-2"
                                           value="<?= $b['penulis'] ?>" required>

                                    <label>Stok</label>
                                    <input type="number" name="stok" class="form-control"
                                           value="<?= $b['stok'] ?>" required>
                                </div>
                                <div class="modal-footer">
                                    <button class="btn btn-warning">Update</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>

                <?php } ?>
            </table>
        </div>
    </div>
</div>

<!-- MODAL TAMBAH -->
<div class="modal fade" id="tambah">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="POST" action="tambah_buku.php">
                <div class="modal-header">
                    <h5 class="modal-title">Tambah Buku</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <label>Judul</label>
                    <input type="text" name="judul" class="form-control mb-2" required>

                    <label>Penulis</label>
                    <input type="text" name="penulis" class="form-control mb-2" required>

                    <label>Stok</label>
                    <input type="number" name="stok" class="form-control" required>
                </div>
                <div class="modal-footer">
                    <button class="btn btn-success">Simpan</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
