<?php
session_start();
include "../config/koneksi.php";

if (!isset($_SESSION['login']) || $_SESSION['role'] != 'admin') {
    header("Location: ../auth/login.php");
    exit;
}

$id = $_GET['id'];
mysqli_query($koneksi, "DELETE FROM transaksi WHERE id='$id'");

header("Location: transaksi.php");
