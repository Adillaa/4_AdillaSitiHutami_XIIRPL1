<?php
session_start();
include "../config/koneksi.php";

if (!isset($_SESSION['login']) || $_SESSION['role'] != 'admin') {
    header("Location: ../auth/login.php");
    exit;
}

$id = $_GET['id'];
$data = mysqli_query($koneksi, "SELECT * FROM transaksi WHERE id='$id'");
$t = mysqli_fetch_assoc($data);

if (isset($_POST['update'])) {
    $tgl_kembali = $_POST['tanggal_kembali'];
    $status = $_POST['status'];

    mysqli_query($koneksi, 
        "UPDATE transaksi SET 
         tanggal_kembali='$tgl_kembali',
         status='$status'
         WHERE id='$id'"
    );

    header("Location: transaksi.php");
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Edit Transaksi</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<div class="container mt-5">
<div class="card shadow-sm">
<div class="card-header bg-warning fw-bold">✏ Edit Transaksi</div>
<div class="card-body">

<form method="POST">
    <label>Tanggal Kembali</label>
    <input type="date" name="tanggal_kembali" 
           value="<?= $t['tanggal_kembali'] ?>" 
           class="form-control mb-3">

    <label>Status</label>
    <select name="status" class="form-control mb-3">
        <option value="dipinjam" <?= $t['status']=='dipinjam'?'selected':'' ?>>Dipinjam</option>
        <option value="dikembalikan" <?= $t['status']=='kembali'?'selected':'' ?>>dikembalikan</option>
    </select>

    <button name="update" class="btn btn-success">Simpan</button>
    <a href="transaksi.php" class="btn btn-secondary">Batal</a>
</form>

</div>
</div>
</div>

</body>
</html>
