<?php
include "../config/koneksi.php";

$id       = mysqli_real_escape_string($koneksi, $_POST['id']);
$nama     = mysqli_real_escape_string($koneksi, $_POST['nama']);
$username = mysqli_real_escape_string($koneksi, $_POST['username']);
$password = $_POST['password'];

// Jika password baru diisi → hash ulang
if (!empty($password)) {
    
    // Gunakan password_hash yang lebih aman (WAJIB UKK modern)
    $hashed = password_hash($password, PASSWORD_DEFAULT);

    $query = "
        UPDATE users SET 
            nama='$nama',
            username='$username',
            password='$hashed'
        WHERE id='$id'
    ";

} else {

    // Tanpa update password
    $query = "
        UPDATE users SET 
            nama='$nama',
            username='$username'
        WHERE id='$id'
    ";
}

mysqli_query($koneksi, $query);
header("Location: anggota.php");
exit;
