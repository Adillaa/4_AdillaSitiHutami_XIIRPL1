<?php
include "../config/koneksi.php";

$id      = $_POST['id'];
$judul   = $_POST['judul'];
$penulis = $_POST['penulis'];
$stok    = $_POST['stok'];

mysqli_query($koneksi, "
    UPDATE buku SET 
        judul='$judul',
        penulis='$penulis',
        stok='$stok'
    WHERE id='$id'
");

header("Location: buku.php");
