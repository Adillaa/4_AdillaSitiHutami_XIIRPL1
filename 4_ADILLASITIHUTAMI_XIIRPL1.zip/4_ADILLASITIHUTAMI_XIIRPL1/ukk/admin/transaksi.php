<?php
session_start();
include "../config/koneksi.php";

if (!isset($_SESSION['login']) || $_SESSION['role'] != 'admin') {
    header("Location: ../auth/login.php");
    exit;
}

$data = mysqli_query($koneksi, 
    "SELECT 
        transaksi.id,
        transaksi.tanggal_pinjam,
        transaksi.tanggal_kembali,
        transaksi.status,
        users.nama,
        buku.judul
     FROM transaksi
     JOIN users ON transaksi.id_user = users.id
     JOIN buku ON transaksi.id_buku = buku.id
     ORDER BY transaksi.id DESC"
);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Data Transaksi</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body class="bg-light">

<div class="container mt-4">

    <!-- HEADER -->
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h4 class="fw-bold">📦 Manajemen Data Transaksi</h4>
        <div>
            <a href="tambah_transaksi.php" class="btn btn-success btn-sm">
                ➕ Tambah Transaksi
            </a>
            <a href="dashboard.php" class="btn btn-secondary btn-sm">
                ⬅ Kembali ke Dashboard
            </a>
        </div>
    </div>

    <!-- CARD TABLE -->
    <div class="card shadow-sm">
        <div class="card-body">

            <?php if (mysqli_num_rows($data) == 0) { ?>
                <div class="alert alert-info text-center">
                    Belum ada data transaksi.
                </div>
            <?php } else { ?>

            <table class="table table-bordered table-hover align-middle">
                <tr class="table-dark text-center">
                    <th width="50">No</th>
                    <th>Nama Anggota</th>
                    <th>Buku</th>
                    <th width="120">Tgl Pinjam</th>
                    <th width="120">Tgl Kembali</th>
                    <th width="120">Status</th>
                    <th width="160">Aksi</th>
                </tr>

                <?php $no=1; while($t=mysqli_fetch_assoc($data)) { ?>
                <tr>
                    <td class="text-center"><?= $no++ ?></td>
                    <td><?= $t['nama'] ?></td>
                    <td><?= $t['judul'] ?></td>
                    <td class="text-center"><?= $t['tanggal_pinjam'] ?></td>
                    <td class="text-center"><?= $t['tanggal_kembali'] ?: '-' ?></td>

                    <!-- STATUS -->
                    <td class="text-center">
                        <?php if ($t['status'] == 'dipinjam') { ?>
                            <span class="badge bg-warning">Dipinjam</span>
                        <?php } elseif ($t['status'] == 'dikembalikan') { ?>
                            <span class="badge bg-success">Dikembalikan</span>
                        <?php } else { ?>
                            <span class="badge bg-secondary">
                                <?= ucfirst($t['status']) ?>
                            </span>
                        <?php } ?>
                    </td>

                    <!-- AKSI -->
                    <td class="text-center">
                        <a href="edit_transaksi.php?id=<?= $t['id'] ?>" 
                           class="btn btn-warning btn-sm">
                            ✏ Edit
                        </a>
                        <a href="hapus_transaksi.php?id=<?= $t['id'] ?>"
                           onclick="return confirm('Hapus transaksi ini?')"
                           class="btn btn-danger btn-sm">
                            🗑 Hapus
                        </a>
                    </td>
                </tr>
                <?php } ?>

            </table>

            <?php } ?>

        </div>
    </div>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
