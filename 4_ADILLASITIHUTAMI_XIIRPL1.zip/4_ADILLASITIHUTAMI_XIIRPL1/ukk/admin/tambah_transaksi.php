<?php
session_start();
include "../config/koneksi.php";

/* VALIDASI ADMIN */
if (!isset($_SESSION['login']) || $_SESSION['role'] != 'admin') {
    header("Location: ../auth/login.php");
    exit;
}

/* AMBIL USER & BUKU */
$user = mysqli_query($koneksi, "SELECT * FROM users WHERE role='user'");
$buku = mysqli_query($koneksi, "SELECT * FROM buku WHERE stok > 0");

if (isset($_POST['simpan'])) {
    $id_user = $_POST['id_user'];
    $id_buku = $_POST['id_buku'];
    $tgl_pinjam = date('Y-m-d');

    /* INSERT TRANSAKSI */
    mysqli_query($koneksi, "
        INSERT INTO transaksi (id_user, id_buku, tanggal_pinjam, status)
        VALUES ('$id_user', '$id_buku', '$tgl_pinjam', 'dipinjam')
    ");

    /* KURANGI STOK */
    mysqli_query($koneksi, "
        UPDATE buku SET stok = stok - 1 WHERE id='$id_buku'
    ");

    header("Location: transaksi.php");
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Tambah Transaksi</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<div class="container mt-5">
<div class="card shadow-sm">
<div class="card-header bg-success text-white fw-bold">
    ➕ Tambah Transaksi
</div>
<div class="card-body">

<form method="POST">

    <label>Nama Anggota</label>
    <select name="id_user" class="form-control mb-3" required>
        <option value="">-- Pilih Anggota --</option>
        <?php while($u=mysqli_fetch_assoc($user)) { ?>
            <option value="<?= $u['id'] ?>"><?= $u['nama'] ?></option>
        <?php } ?>
    </select>

    <label>Buku</label>
    <select name="id_buku" class="form-control mb-3" required>
        <option value="">-- Pilih Buku --</option>
        <?php while($b=mysqli_fetch_assoc($buku)) { ?>
            <option value="<?= $b['id'] ?>">
                <?= $b['judul'] ?> (Stok: <?= $b['stok'] ?>)
            </option>
        <?php } ?>
    </select>

    <button name="simpan" class="btn btn-success">Simpan</button>
    <a href="transaksi.php" class="btn btn-secondary">Batal</a>

</form>

</div>
</div>
</div>

</body>
</html>
