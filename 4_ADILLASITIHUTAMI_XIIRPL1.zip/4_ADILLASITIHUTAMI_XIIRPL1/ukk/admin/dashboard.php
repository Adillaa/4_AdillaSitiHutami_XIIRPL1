<?php
session_start();
if ($_SESSION['role'] != 'admin') {
    header("Location: ../auth/login.php");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Admin Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        body {
            background: linear-gradient(135deg, #f0f4ff, #f8f9fa);
            min-height: 100vh;
        }

        .navbar {
            box-shadow: 0 4px 15px rgba(0,0,0,.15);
        }

        .dashboard-title {
            font-weight: 700;
            color: #333;
        }

        .card-link {
            text-decoration: none;
            color: inherit;
        }

        .dashboard-card {
            border-radius: 18px;
            transition: .3s;
            box-shadow: 0 10px 25px rgba(0,0,0,.1);
        }

        .dashboard-card:hover {
            transform: translateY(-8px);
            box-shadow: 0 15px 35px rgba(0,0,0,.2);
        }

        .icon-box {
            width: 70px;
            height: 70px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 32px;
            margin: auto;
            color: #fff;
        }
    </style>
</head>

<body>

<!-- NAVBAR -->
<nav class="navbar navbar-dark bg-dark">
    <div class="container">
        <span class="navbar-brand fw-bold">
            📘 Admin Perpustakaan
        </span>

        <div class="d-flex align-items-center gap-3">
            <span class="text-white small">
                👤 <?= $_SESSION['nama']; ?>
            </span>
            <a href="../auth/logout.php" class="btn btn-light btn-sm">
                Logout
            </a>
        </div>
    </div>
</nav>

<div class="container mt-5">

    <!-- JUDUL -->
    <div class="text-center mb-4">
        <h3 class="dashboard-title">Dashboard Admin</h3>
        <p class="text-muted">Kelola sistem perpustakaan dengan mudah</p>
    </div>

    <!-- MENU -->
    <div class="row g-4 text-center">

        <!-- KELOLA BUKU -->
        <div class="col-md-4">
            <a href="buku.php" class="card-link">
                <div class="card dashboard-card p-4">
                    <div class="icon-box bg-success mb-3">📚</div>
                    <h5 class="fw-bold">Kelola Buku</h5>
                    <p class="text-muted small">
                        Tambah, edit, dan hapus koleksi buku
                    </p>
                </div>
            </a>
        </div>

        <!-- KELOLA ANGGOTA -->
        <div class="col-md-4">
            <a href="anggota.php" class="card-link">
                <div class="card dashboard-card p-4">
                    <div class="icon-box bg-warning mb-3">👥</div>
                    <h5 class="fw-bold">Kelola Anggota</h5>
                    <p class="text-muted small">
                        Manajemen data user perpustakaan
                    </p>
                </div>
            </a>
        </div>

        <!-- TRANSAKSI -->
        <div class="col-md-4">
            <a href="transaksi.php" class="card-link">
                <div class="card dashboard-card p-4">
                    <div class="icon-box bg-danger mb-3">🔄</div>
                    <h5 class="fw-bold">Transaksi</h5>
                    <p class="text-muted small">
                        Peminjaman & pengembalian buku
                    </p>
                </div>
            </a>
        </div>

    </div>
</div>

</body>
</html>
