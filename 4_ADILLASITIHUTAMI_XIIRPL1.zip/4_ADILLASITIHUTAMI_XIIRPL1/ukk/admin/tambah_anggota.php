<?php
include "../config/koneksi.php";

$pass = password_hash($_POST['password'], PASSWORD_DEFAULT);

mysqli_query($koneksi, "INSERT INTO users VALUES (
    NULL,
    '$_POST[nama]',
    '$_POST[username]',
    '$pass',
    'user'
)");

header("Location: anggota.php");
