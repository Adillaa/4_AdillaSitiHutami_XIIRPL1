<?php
include "../config/koneksi.php";

mysqli_query($koneksi, "INSERT INTO buku VALUES (
    NULL,
    '$_POST[judul]',
    '$_POST[penulis]',
    '$_POST[stok]'
)");

header("Location: buku.php");
